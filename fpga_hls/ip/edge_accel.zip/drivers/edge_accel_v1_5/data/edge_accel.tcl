# ==============================================================
# Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
# Tool Version Limit: 2025.11
# Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
# Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
# 
# ==============================================================
proc generate {drv_handle} {
    xdefine_include_file $drv_handle "xparameters.h" "XEdge_accel" \
        "NUM_INSTANCES" \
        "DEVICE_ID" \
        "C_S_AXI_CTRL_BASEADDR" \
        "C_S_AXI_CTRL_HIGHADDR" \
        "C_S_AXI_GAMMA_BASEADDR" \
        "C_S_AXI_GAMMA_HIGHADDR"

    xdefine_config_file $drv_handle "xedge_accel_g.c" "XEdge_accel" \
        "DEVICE_ID" \
        "C_S_AXI_CTRL_BASEADDR" \
        "C_S_AXI_GAMMA_BASEADDR"

    xdefine_canonical_xpars $drv_handle "xparameters.h" "XEdge_accel" \
        "DEVICE_ID" \
        "C_S_AXI_CTRL_BASEADDR" \
        "C_S_AXI_CTRL_HIGHADDR" \
        "C_S_AXI_GAMMA_BASEADDR" \
        "C_S_AXI_GAMMA_HIGHADDR"
}

