// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XEDGE_ACCEL_H
#define XEDGE_ACCEL_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xedge_accel_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Ctrl_BaseAddress;
    u64 Gamma_BaseAddress;
} XEdge_accel_Config;
#endif

typedef struct {
    u64 Ctrl_BaseAddress;
    u64 Gamma_BaseAddress;
    u32 IsReady;
} XEdge_accel;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XEdge_accel_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XEdge_accel_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XEdge_accel_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XEdge_accel_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XEdge_accel_Initialize(XEdge_accel *InstancePtr, UINTPTR BaseAddress);
XEdge_accel_Config* XEdge_accel_LookupConfig(UINTPTR BaseAddress);
#else
int XEdge_accel_Initialize(XEdge_accel *InstancePtr, u16 DeviceId);
XEdge_accel_Config* XEdge_accel_LookupConfig(u16 DeviceId);
#endif
int XEdge_accel_CfgInitialize(XEdge_accel *InstancePtr, XEdge_accel_Config *ConfigPtr);
#else
int XEdge_accel_Initialize(XEdge_accel *InstancePtr, const char* InstanceName);
int XEdge_accel_Release(XEdge_accel *InstancePtr);
#endif

void XEdge_accel_Start(XEdge_accel *InstancePtr);
u32 XEdge_accel_IsDone(XEdge_accel *InstancePtr);
u32 XEdge_accel_IsIdle(XEdge_accel *InstancePtr);
u32 XEdge_accel_IsReady(XEdge_accel *InstancePtr);
void XEdge_accel_EnableAutoRestart(XEdge_accel *InstancePtr);
void XEdge_accel_DisableAutoRestart(XEdge_accel *InstancePtr);

void XEdge_accel_Set_rows(XEdge_accel *InstancePtr, u32 Data);
u32 XEdge_accel_Get_rows(XEdge_accel *InstancePtr);
void XEdge_accel_Set_cols(XEdge_accel *InstancePtr, u32 Data);
u32 XEdge_accel_Get_cols(XEdge_accel *InstancePtr);
void XEdge_accel_Set_pre0_op(XEdge_accel *InstancePtr, u32 Data);
u32 XEdge_accel_Get_pre0_op(XEdge_accel *InstancePtr);
void XEdge_accel_Set_pre0_p0(XEdge_accel *InstancePtr, u32 Data);
u32 XEdge_accel_Get_pre0_p0(XEdge_accel *InstancePtr);
void XEdge_accel_Set_pre0_p1(XEdge_accel *InstancePtr, u32 Data);
u32 XEdge_accel_Get_pre0_p1(XEdge_accel *InstancePtr);
void XEdge_accel_Set_pre0_p2(XEdge_accel *InstancePtr, u32 Data);
u32 XEdge_accel_Get_pre0_p2(XEdge_accel *InstancePtr);
void XEdge_accel_Set_pre0_p3(XEdge_accel *InstancePtr, u32 Data);
u32 XEdge_accel_Get_pre0_p3(XEdge_accel *InstancePtr);
void XEdge_accel_Set_pre1_op(XEdge_accel *InstancePtr, u32 Data);
u32 XEdge_accel_Get_pre1_op(XEdge_accel *InstancePtr);
void XEdge_accel_Set_pre1_p0(XEdge_accel *InstancePtr, u32 Data);
u32 XEdge_accel_Get_pre1_p0(XEdge_accel *InstancePtr);
void XEdge_accel_Set_pre1_p1(XEdge_accel *InstancePtr, u32 Data);
u32 XEdge_accel_Get_pre1_p1(XEdge_accel *InstancePtr);
void XEdge_accel_Set_pre1_p2(XEdge_accel *InstancePtr, u32 Data);
u32 XEdge_accel_Get_pre1_p2(XEdge_accel *InstancePtr);
void XEdge_accel_Set_pre1_p3(XEdge_accel *InstancePtr, u32 Data);
u32 XEdge_accel_Get_pre1_p3(XEdge_accel *InstancePtr);
void XEdge_accel_Set_pre2_op(XEdge_accel *InstancePtr, u32 Data);
u32 XEdge_accel_Get_pre2_op(XEdge_accel *InstancePtr);
void XEdge_accel_Set_pre2_p0(XEdge_accel *InstancePtr, u32 Data);
u32 XEdge_accel_Get_pre2_p0(XEdge_accel *InstancePtr);
void XEdge_accel_Set_pre2_p1(XEdge_accel *InstancePtr, u32 Data);
u32 XEdge_accel_Get_pre2_p1(XEdge_accel *InstancePtr);
void XEdge_accel_Set_pre2_p2(XEdge_accel *InstancePtr, u32 Data);
u32 XEdge_accel_Get_pre2_p2(XEdge_accel *InstancePtr);
void XEdge_accel_Set_pre2_p3(XEdge_accel *InstancePtr, u32 Data);
u32 XEdge_accel_Get_pre2_p3(XEdge_accel *InstancePtr);
void XEdge_accel_Set_edge_op(XEdge_accel *InstancePtr, u32 Data);
u32 XEdge_accel_Get_edge_op(XEdge_accel *InstancePtr);
void XEdge_accel_Set_edge_p0(XEdge_accel *InstancePtr, u32 Data);
u32 XEdge_accel_Get_edge_p0(XEdge_accel *InstancePtr);
void XEdge_accel_Set_edge_p1(XEdge_accel *InstancePtr, u32 Data);
u32 XEdge_accel_Get_edge_p1(XEdge_accel *InstancePtr);
void XEdge_accel_Set_edge_p2(XEdge_accel *InstancePtr, u32 Data);
u32 XEdge_accel_Get_edge_p2(XEdge_accel *InstancePtr);
void XEdge_accel_Set_edge_p3(XEdge_accel *InstancePtr, u32 Data);
u32 XEdge_accel_Get_edge_p3(XEdge_accel *InstancePtr);
void XEdge_accel_Set_post0_op(XEdge_accel *InstancePtr, u32 Data);
u32 XEdge_accel_Get_post0_op(XEdge_accel *InstancePtr);
void XEdge_accel_Set_post0_p0(XEdge_accel *InstancePtr, u32 Data);
u32 XEdge_accel_Get_post0_p0(XEdge_accel *InstancePtr);
void XEdge_accel_Set_post0_p1(XEdge_accel *InstancePtr, u32 Data);
u32 XEdge_accel_Get_post0_p1(XEdge_accel *InstancePtr);
void XEdge_accel_Set_post0_p2(XEdge_accel *InstancePtr, u32 Data);
u32 XEdge_accel_Get_post0_p2(XEdge_accel *InstancePtr);
void XEdge_accel_Set_post0_p3(XEdge_accel *InstancePtr, u32 Data);
u32 XEdge_accel_Get_post0_p3(XEdge_accel *InstancePtr);
void XEdge_accel_Set_post1_op(XEdge_accel *InstancePtr, u32 Data);
u32 XEdge_accel_Get_post1_op(XEdge_accel *InstancePtr);
void XEdge_accel_Set_post1_p0(XEdge_accel *InstancePtr, u32 Data);
u32 XEdge_accel_Get_post1_p0(XEdge_accel *InstancePtr);
void XEdge_accel_Set_post1_p1(XEdge_accel *InstancePtr, u32 Data);
u32 XEdge_accel_Get_post1_p1(XEdge_accel *InstancePtr);
void XEdge_accel_Set_post1_p2(XEdge_accel *InstancePtr, u32 Data);
u32 XEdge_accel_Get_post1_p2(XEdge_accel *InstancePtr);
void XEdge_accel_Set_post1_p3(XEdge_accel *InstancePtr, u32 Data);
u32 XEdge_accel_Get_post1_p3(XEdge_accel *InstancePtr);
u32 XEdge_accel_Get_status(XEdge_accel *InstancePtr);
u32 XEdge_accel_Get_status_vld(XEdge_accel *InstancePtr);
u32 XEdge_accel_Get_capability(XEdge_accel *InstancePtr);
u32 XEdge_accel_Get_capability_vld(XEdge_accel *InstancePtr);
u32 XEdge_accel_Get_gamma_lut_BaseAddress(XEdge_accel *InstancePtr);
u32 XEdge_accel_Get_gamma_lut_HighAddress(XEdge_accel *InstancePtr);
u32 XEdge_accel_Get_gamma_lut_TotalBytes(XEdge_accel *InstancePtr);
u32 XEdge_accel_Get_gamma_lut_BitWidth(XEdge_accel *InstancePtr);
u32 XEdge_accel_Get_gamma_lut_Depth(XEdge_accel *InstancePtr);
u32 XEdge_accel_Write_gamma_lut_Words(XEdge_accel *InstancePtr, int offset, word_type *data, int length);
u32 XEdge_accel_Read_gamma_lut_Words(XEdge_accel *InstancePtr, int offset, word_type *data, int length);
u32 XEdge_accel_Write_gamma_lut_Bytes(XEdge_accel *InstancePtr, int offset, char *data, int length);
u32 XEdge_accel_Read_gamma_lut_Bytes(XEdge_accel *InstancePtr, int offset, char *data, int length);

void XEdge_accel_InterruptGlobalEnable(XEdge_accel *InstancePtr);
void XEdge_accel_InterruptGlobalDisable(XEdge_accel *InstancePtr);
void XEdge_accel_InterruptEnable(XEdge_accel *InstancePtr, u32 Mask);
void XEdge_accel_InterruptDisable(XEdge_accel *InstancePtr, u32 Mask);
void XEdge_accel_InterruptClear(XEdge_accel *InstancePtr, u32 Mask);
u32 XEdge_accel_InterruptGetEnabled(XEdge_accel *InstancePtr);
u32 XEdge_accel_InterruptGetStatus(XEdge_accel *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
