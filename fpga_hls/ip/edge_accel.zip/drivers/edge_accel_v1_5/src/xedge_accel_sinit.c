// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xedge_accel.h"

extern XEdge_accel_Config XEdge_accel_ConfigTable[];

#ifdef SDT
XEdge_accel_Config *XEdge_accel_LookupConfig(UINTPTR BaseAddress) {
	XEdge_accel_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XEdge_accel_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XEdge_accel_ConfigTable[Index].Ctrl_BaseAddress == BaseAddress) {
			ConfigPtr = &XEdge_accel_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XEdge_accel_Initialize(XEdge_accel *InstancePtr, UINTPTR BaseAddress) {
	XEdge_accel_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XEdge_accel_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XEdge_accel_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XEdge_accel_Config *XEdge_accel_LookupConfig(u16 DeviceId) {
	XEdge_accel_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XEDGE_ACCEL_NUM_INSTANCES; Index++) {
		if (XEdge_accel_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XEdge_accel_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XEdge_accel_Initialize(XEdge_accel *InstancePtr, u16 DeviceId) {
	XEdge_accel_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XEdge_accel_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XEdge_accel_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

