// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xedge_accel.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XEdge_accel_CfgInitialize(XEdge_accel *InstancePtr, XEdge_accel_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Ctrl_BaseAddress = ConfigPtr->Ctrl_BaseAddress;
    InstancePtr->Gamma_BaseAddress = ConfigPtr->Gamma_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XEdge_accel_Start(XEdge_accel *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_AP_CTRL) & 0x80;
    XEdge_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XEdge_accel_IsDone(XEdge_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XEdge_accel_IsIdle(XEdge_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XEdge_accel_IsReady(XEdge_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XEdge_accel_EnableAutoRestart(XEdge_accel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEdge_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_AP_CTRL, 0x80);
}

void XEdge_accel_DisableAutoRestart(XEdge_accel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEdge_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_AP_CTRL, 0);
}

void XEdge_accel_Set_rows(XEdge_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEdge_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_ROWS_DATA, Data);
}

u32 XEdge_accel_Get_rows(XEdge_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_ROWS_DATA);
    return Data;
}

void XEdge_accel_Set_cols(XEdge_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEdge_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_COLS_DATA, Data);
}

u32 XEdge_accel_Get_cols(XEdge_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_COLS_DATA);
    return Data;
}

void XEdge_accel_Set_pre0_op(XEdge_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEdge_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_PRE0_OP_DATA, Data);
}

u32 XEdge_accel_Get_pre0_op(XEdge_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_PRE0_OP_DATA);
    return Data;
}

void XEdge_accel_Set_pre0_p0(XEdge_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEdge_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_PRE0_P0_DATA, Data);
}

u32 XEdge_accel_Get_pre0_p0(XEdge_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_PRE0_P0_DATA);
    return Data;
}

void XEdge_accel_Set_pre0_p1(XEdge_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEdge_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_PRE0_P1_DATA, Data);
}

u32 XEdge_accel_Get_pre0_p1(XEdge_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_PRE0_P1_DATA);
    return Data;
}

void XEdge_accel_Set_pre0_p2(XEdge_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEdge_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_PRE0_P2_DATA, Data);
}

u32 XEdge_accel_Get_pre0_p2(XEdge_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_PRE0_P2_DATA);
    return Data;
}

void XEdge_accel_Set_pre0_p3(XEdge_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEdge_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_PRE0_P3_DATA, Data);
}

u32 XEdge_accel_Get_pre0_p3(XEdge_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_PRE0_P3_DATA);
    return Data;
}

void XEdge_accel_Set_pre1_op(XEdge_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEdge_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_PRE1_OP_DATA, Data);
}

u32 XEdge_accel_Get_pre1_op(XEdge_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_PRE1_OP_DATA);
    return Data;
}

void XEdge_accel_Set_pre1_p0(XEdge_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEdge_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_PRE1_P0_DATA, Data);
}

u32 XEdge_accel_Get_pre1_p0(XEdge_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_PRE1_P0_DATA);
    return Data;
}

void XEdge_accel_Set_pre1_p1(XEdge_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEdge_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_PRE1_P1_DATA, Data);
}

u32 XEdge_accel_Get_pre1_p1(XEdge_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_PRE1_P1_DATA);
    return Data;
}

void XEdge_accel_Set_pre1_p2(XEdge_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEdge_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_PRE1_P2_DATA, Data);
}

u32 XEdge_accel_Get_pre1_p2(XEdge_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_PRE1_P2_DATA);
    return Data;
}

void XEdge_accel_Set_pre1_p3(XEdge_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEdge_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_PRE1_P3_DATA, Data);
}

u32 XEdge_accel_Get_pre1_p3(XEdge_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_PRE1_P3_DATA);
    return Data;
}

void XEdge_accel_Set_pre2_op(XEdge_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEdge_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_PRE2_OP_DATA, Data);
}

u32 XEdge_accel_Get_pre2_op(XEdge_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_PRE2_OP_DATA);
    return Data;
}

void XEdge_accel_Set_pre2_p0(XEdge_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEdge_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_PRE2_P0_DATA, Data);
}

u32 XEdge_accel_Get_pre2_p0(XEdge_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_PRE2_P0_DATA);
    return Data;
}

void XEdge_accel_Set_pre2_p1(XEdge_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEdge_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_PRE2_P1_DATA, Data);
}

u32 XEdge_accel_Get_pre2_p1(XEdge_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_PRE2_P1_DATA);
    return Data;
}

void XEdge_accel_Set_pre2_p2(XEdge_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEdge_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_PRE2_P2_DATA, Data);
}

u32 XEdge_accel_Get_pre2_p2(XEdge_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_PRE2_P2_DATA);
    return Data;
}

void XEdge_accel_Set_pre2_p3(XEdge_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEdge_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_PRE2_P3_DATA, Data);
}

u32 XEdge_accel_Get_pre2_p3(XEdge_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_PRE2_P3_DATA);
    return Data;
}

void XEdge_accel_Set_edge_op(XEdge_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEdge_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_EDGE_OP_DATA, Data);
}

u32 XEdge_accel_Get_edge_op(XEdge_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_EDGE_OP_DATA);
    return Data;
}

void XEdge_accel_Set_edge_p0(XEdge_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEdge_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_EDGE_P0_DATA, Data);
}

u32 XEdge_accel_Get_edge_p0(XEdge_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_EDGE_P0_DATA);
    return Data;
}

void XEdge_accel_Set_edge_p1(XEdge_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEdge_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_EDGE_P1_DATA, Data);
}

u32 XEdge_accel_Get_edge_p1(XEdge_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_EDGE_P1_DATA);
    return Data;
}

void XEdge_accel_Set_edge_p2(XEdge_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEdge_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_EDGE_P2_DATA, Data);
}

u32 XEdge_accel_Get_edge_p2(XEdge_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_EDGE_P2_DATA);
    return Data;
}

void XEdge_accel_Set_edge_p3(XEdge_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEdge_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_EDGE_P3_DATA, Data);
}

u32 XEdge_accel_Get_edge_p3(XEdge_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_EDGE_P3_DATA);
    return Data;
}

void XEdge_accel_Set_post0_op(XEdge_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEdge_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_POST0_OP_DATA, Data);
}

u32 XEdge_accel_Get_post0_op(XEdge_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_POST0_OP_DATA);
    return Data;
}

void XEdge_accel_Set_post0_p0(XEdge_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEdge_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_POST0_P0_DATA, Data);
}

u32 XEdge_accel_Get_post0_p0(XEdge_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_POST0_P0_DATA);
    return Data;
}

void XEdge_accel_Set_post0_p1(XEdge_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEdge_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_POST0_P1_DATA, Data);
}

u32 XEdge_accel_Get_post0_p1(XEdge_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_POST0_P1_DATA);
    return Data;
}

void XEdge_accel_Set_post0_p2(XEdge_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEdge_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_POST0_P2_DATA, Data);
}

u32 XEdge_accel_Get_post0_p2(XEdge_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_POST0_P2_DATA);
    return Data;
}

void XEdge_accel_Set_post0_p3(XEdge_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEdge_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_POST0_P3_DATA, Data);
}

u32 XEdge_accel_Get_post0_p3(XEdge_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_POST0_P3_DATA);
    return Data;
}

void XEdge_accel_Set_post1_op(XEdge_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEdge_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_POST1_OP_DATA, Data);
}

u32 XEdge_accel_Get_post1_op(XEdge_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_POST1_OP_DATA);
    return Data;
}

void XEdge_accel_Set_post1_p0(XEdge_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEdge_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_POST1_P0_DATA, Data);
}

u32 XEdge_accel_Get_post1_p0(XEdge_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_POST1_P0_DATA);
    return Data;
}

void XEdge_accel_Set_post1_p1(XEdge_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEdge_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_POST1_P1_DATA, Data);
}

u32 XEdge_accel_Get_post1_p1(XEdge_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_POST1_P1_DATA);
    return Data;
}

void XEdge_accel_Set_post1_p2(XEdge_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEdge_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_POST1_P2_DATA, Data);
}

u32 XEdge_accel_Get_post1_p2(XEdge_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_POST1_P2_DATA);
    return Data;
}

void XEdge_accel_Set_post1_p3(XEdge_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEdge_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_POST1_P3_DATA, Data);
}

u32 XEdge_accel_Get_post1_p3(XEdge_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_POST1_P3_DATA);
    return Data;
}

u32 XEdge_accel_Get_status(XEdge_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_STATUS_DATA);
    return Data;
}

u32 XEdge_accel_Get_status_vld(XEdge_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_STATUS_CTRL);
    return Data & 0x1;
}

u32 XEdge_accel_Get_capability(XEdge_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_CAPABILITY_DATA);
    return Data;
}

u32 XEdge_accel_Get_capability_vld(XEdge_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_CAPABILITY_CTRL);
    return Data & 0x1;
}

u32 XEdge_accel_Get_gamma_lut_BaseAddress(XEdge_accel *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Gamma_BaseAddress + XEDGE_ACCEL_GAMMA_ADDR_GAMMA_LUT_BASE);
}

u32 XEdge_accel_Get_gamma_lut_HighAddress(XEdge_accel *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Gamma_BaseAddress + XEDGE_ACCEL_GAMMA_ADDR_GAMMA_LUT_HIGH);
}

u32 XEdge_accel_Get_gamma_lut_TotalBytes(XEdge_accel *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XEDGE_ACCEL_GAMMA_ADDR_GAMMA_LUT_HIGH - XEDGE_ACCEL_GAMMA_ADDR_GAMMA_LUT_BASE + 1);
}

u32 XEdge_accel_Get_gamma_lut_BitWidth(XEdge_accel *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XEDGE_ACCEL_GAMMA_WIDTH_GAMMA_LUT;
}

u32 XEdge_accel_Get_gamma_lut_Depth(XEdge_accel *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XEDGE_ACCEL_GAMMA_DEPTH_GAMMA_LUT;
}

u32 XEdge_accel_Write_gamma_lut_Words(XEdge_accel *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XEDGE_ACCEL_GAMMA_ADDR_GAMMA_LUT_HIGH - XEDGE_ACCEL_GAMMA_ADDR_GAMMA_LUT_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Gamma_BaseAddress + XEDGE_ACCEL_GAMMA_ADDR_GAMMA_LUT_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XEdge_accel_Read_gamma_lut_Words(XEdge_accel *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XEDGE_ACCEL_GAMMA_ADDR_GAMMA_LUT_HIGH - XEDGE_ACCEL_GAMMA_ADDR_GAMMA_LUT_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Gamma_BaseAddress + XEDGE_ACCEL_GAMMA_ADDR_GAMMA_LUT_BASE + (offset + i)*4);
    }
    return length;
}

u32 XEdge_accel_Write_gamma_lut_Bytes(XEdge_accel *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XEDGE_ACCEL_GAMMA_ADDR_GAMMA_LUT_HIGH - XEDGE_ACCEL_GAMMA_ADDR_GAMMA_LUT_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Gamma_BaseAddress + XEDGE_ACCEL_GAMMA_ADDR_GAMMA_LUT_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XEdge_accel_Read_gamma_lut_Bytes(XEdge_accel *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XEDGE_ACCEL_GAMMA_ADDR_GAMMA_LUT_HIGH - XEDGE_ACCEL_GAMMA_ADDR_GAMMA_LUT_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Gamma_BaseAddress + XEDGE_ACCEL_GAMMA_ADDR_GAMMA_LUT_BASE + offset + i);
    }
    return length;
}

void XEdge_accel_InterruptGlobalEnable(XEdge_accel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEdge_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_GIE, 1);
}

void XEdge_accel_InterruptGlobalDisable(XEdge_accel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEdge_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_GIE, 0);
}

void XEdge_accel_InterruptEnable(XEdge_accel *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_IER);
    XEdge_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_IER, Register | Mask);
}

void XEdge_accel_InterruptDisable(XEdge_accel *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_IER);
    XEdge_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_IER, Register & (~Mask));
}

void XEdge_accel_InterruptClear(XEdge_accel *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEdge_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_ISR, Mask);
}

u32 XEdge_accel_InterruptGetEnabled(XEdge_accel *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_IER);
}

u32 XEdge_accel_InterruptGetStatus(XEdge_accel *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XEdge_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XEDGE_ACCEL_CTRL_ADDR_ISR);
}

