// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
`timescale 1ns/1ps
(* DowngradeIPIdentifiedWarnings="yes" *) module edge_accel_CTRL_s_axi
#(parameter
    C_S_AXI_ADDR_WIDTH = 9,
    C_S_AXI_DATA_WIDTH = 32
)(
    input  wire                          ACLK,
    input  wire                          ARESET,
    input  wire                          ACLK_EN,
    input  wire [C_S_AXI_ADDR_WIDTH-1:0] AWADDR,
    input  wire                          AWVALID,
    output wire                          AWREADY,
    input  wire [C_S_AXI_DATA_WIDTH-1:0] WDATA,
    input  wire [C_S_AXI_DATA_WIDTH/8-1:0] WSTRB,
    input  wire                          WVALID,
    output wire                          WREADY,
    output wire [1:0]                    BRESP,
    output wire                          BVALID,
    input  wire                          BREADY,
    input  wire [C_S_AXI_ADDR_WIDTH-1:0] ARADDR,
    input  wire                          ARVALID,
    output wire                          ARREADY,
    output wire [C_S_AXI_DATA_WIDTH-1:0] RDATA,
    output wire [1:0]                    RRESP,
    output wire                          RVALID,
    input  wire                          RREADY,
    output wire                          interrupt,
    output wire [31:0]                   rows,
    output wire [31:0]                   cols,
    output wire [7:0]                    pre0_op,
    output wire [31:0]                   pre0_p0,
    output wire [31:0]                   pre0_p1,
    output wire [31:0]                   pre0_p2,
    output wire [31:0]                   pre0_p3,
    output wire [7:0]                    pre1_op,
    output wire [31:0]                   pre1_p0,
    output wire [31:0]                   pre1_p1,
    output wire [31:0]                   pre1_p2,
    output wire [31:0]                   pre1_p3,
    output wire [7:0]                    pre2_op,
    output wire [31:0]                   pre2_p0,
    output wire [31:0]                   pre2_p1,
    output wire [31:0]                   pre2_p2,
    output wire [31:0]                   pre2_p3,
    output wire [7:0]                    edge_op,
    output wire [31:0]                   edge_p0,
    output wire [31:0]                   edge_p1,
    output wire [31:0]                   edge_p2,
    output wire [31:0]                   edge_p3,
    output wire [7:0]                    post0_op,
    output wire [31:0]                   post0_p0,
    output wire [31:0]                   post0_p1,
    output wire [31:0]                   post0_p2,
    output wire [31:0]                   post0_p3,
    output wire [7:0]                    post1_op,
    output wire [31:0]                   post1_p0,
    output wire [31:0]                   post1_p1,
    output wire [31:0]                   post1_p2,
    output wire [31:0]                   post1_p3,
    input  wire [31:0]                   status,
    input  wire                          status_ap_vld,
    input  wire [31:0]                   capability,
    input  wire                          capability_ap_vld,
    output wire                          ap_start,
    input  wire                          ap_done,
    input  wire                          ap_ready,
    input  wire                          ap_idle
);
//------------------------Address Info-------------------
// Protocol Used: ap_ctrl_hs
//
// 0x000 : Control signals
//         bit 0  - ap_start (Read/Write/COH)
//         bit 1  - ap_done (Read/COR)
//         bit 2  - ap_idle (Read)
//         bit 3  - ap_ready (Read/COR)
//         bit 7  - auto_restart (Read/Write)
//         bit 9  - interrupt (Read)
//         others - reserved
// 0x004 : Global Interrupt Enable Register
//         bit 0  - Global Interrupt Enable (Read/Write)
//         others - reserved
// 0x008 : IP Interrupt Enable Register (Read/Write)
//         bit 0 - enable ap_done interrupt (Read/Write)
//         bit 1 - enable ap_ready interrupt (Read/Write)
//         others - reserved
// 0x00c : IP Interrupt Status Register (Read/TOW)
//         bit 0 - ap_done (Read/TOW)
//         bit 1 - ap_ready (Read/TOW)
//         others - reserved
// 0x010 : Data signal of rows
//         bit 31~0 - rows[31:0] (Read/Write)
// 0x014 : reserved
// 0x018 : Data signal of cols
//         bit 31~0 - cols[31:0] (Read/Write)
// 0x01c : reserved
// 0x020 : Data signal of pre0_op
//         bit 7~0 - pre0_op[7:0] (Read/Write)
//         others  - reserved
// 0x024 : reserved
// 0x028 : Data signal of pre0_p0
//         bit 31~0 - pre0_p0[31:0] (Read/Write)
// 0x02c : reserved
// 0x030 : Data signal of pre0_p1
//         bit 31~0 - pre0_p1[31:0] (Read/Write)
// 0x034 : reserved
// 0x038 : Data signal of pre0_p2
//         bit 31~0 - pre0_p2[31:0] (Read/Write)
// 0x03c : reserved
// 0x040 : Data signal of pre0_p3
//         bit 31~0 - pre0_p3[31:0] (Read/Write)
// 0x044 : reserved
// 0x048 : Data signal of pre1_op
//         bit 7~0 - pre1_op[7:0] (Read/Write)
//         others  - reserved
// 0x04c : reserved
// 0x050 : Data signal of pre1_p0
//         bit 31~0 - pre1_p0[31:0] (Read/Write)
// 0x054 : reserved
// 0x058 : Data signal of pre1_p1
//         bit 31~0 - pre1_p1[31:0] (Read/Write)
// 0x05c : reserved
// 0x060 : Data signal of pre1_p2
//         bit 31~0 - pre1_p2[31:0] (Read/Write)
// 0x064 : reserved
// 0x068 : Data signal of pre1_p3
//         bit 31~0 - pre1_p3[31:0] (Read/Write)
// 0x06c : reserved
// 0x070 : Data signal of pre2_op
//         bit 7~0 - pre2_op[7:0] (Read/Write)
//         others  - reserved
// 0x074 : reserved
// 0x078 : Data signal of pre2_p0
//         bit 31~0 - pre2_p0[31:0] (Read/Write)
// 0x07c : reserved
// 0x080 : Data signal of pre2_p1
//         bit 31~0 - pre2_p1[31:0] (Read/Write)
// 0x084 : reserved
// 0x088 : Data signal of pre2_p2
//         bit 31~0 - pre2_p2[31:0] (Read/Write)
// 0x08c : reserved
// 0x090 : Data signal of pre2_p3
//         bit 31~0 - pre2_p3[31:0] (Read/Write)
// 0x094 : reserved
// 0x098 : Data signal of edge_op
//         bit 7~0 - edge_op[7:0] (Read/Write)
//         others  - reserved
// 0x09c : reserved
// 0x0a0 : Data signal of edge_p0
//         bit 31~0 - edge_p0[31:0] (Read/Write)
// 0x0a4 : reserved
// 0x0a8 : Data signal of edge_p1
//         bit 31~0 - edge_p1[31:0] (Read/Write)
// 0x0ac : reserved
// 0x0b0 : Data signal of edge_p2
//         bit 31~0 - edge_p2[31:0] (Read/Write)
// 0x0b4 : reserved
// 0x0b8 : Data signal of edge_p3
//         bit 31~0 - edge_p3[31:0] (Read/Write)
// 0x0bc : reserved
// 0x0c0 : Data signal of post0_op
//         bit 7~0 - post0_op[7:0] (Read/Write)
//         others  - reserved
// 0x0c4 : reserved
// 0x0c8 : Data signal of post0_p0
//         bit 31~0 - post0_p0[31:0] (Read/Write)
// 0x0cc : reserved
// 0x0d0 : Data signal of post0_p1
//         bit 31~0 - post0_p1[31:0] (Read/Write)
// 0x0d4 : reserved
// 0x0d8 : Data signal of post0_p2
//         bit 31~0 - post0_p2[31:0] (Read/Write)
// 0x0dc : reserved
// 0x0e0 : Data signal of post0_p3
//         bit 31~0 - post0_p3[31:0] (Read/Write)
// 0x0e4 : reserved
// 0x0e8 : Data signal of post1_op
//         bit 7~0 - post1_op[7:0] (Read/Write)
//         others  - reserved
// 0x0ec : reserved
// 0x0f0 : Data signal of post1_p0
//         bit 31~0 - post1_p0[31:0] (Read/Write)
// 0x0f4 : reserved
// 0x0f8 : Data signal of post1_p1
//         bit 31~0 - post1_p1[31:0] (Read/Write)
// 0x0fc : reserved
// 0x100 : Data signal of post1_p2
//         bit 31~0 - post1_p2[31:0] (Read/Write)
// 0x104 : reserved
// 0x108 : Data signal of post1_p3
//         bit 31~0 - post1_p3[31:0] (Read/Write)
// 0x10c : reserved
// 0x110 : Data signal of status
//         bit 31~0 - status[31:0] (Read)
// 0x114 : Control signal of status
//         bit 0  - status_ap_vld (Read/COR)
//         others - reserved
// 0x120 : Data signal of capability
//         bit 31~0 - capability[31:0] (Read)
// 0x124 : Control signal of capability
//         bit 0  - capability_ap_vld (Read/COR)
//         others - reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

//------------------------Parameter----------------------
localparam
    ADDR_AP_CTRL           = 9'h000,
    ADDR_GIE               = 9'h004,
    ADDR_IER               = 9'h008,
    ADDR_ISR               = 9'h00c,
    ADDR_ROWS_DATA_0       = 9'h010,
    ADDR_ROWS_CTRL         = 9'h014,
    ADDR_COLS_DATA_0       = 9'h018,
    ADDR_COLS_CTRL         = 9'h01c,
    ADDR_PRE0_OP_DATA_0    = 9'h020,
    ADDR_PRE0_OP_CTRL      = 9'h024,
    ADDR_PRE0_P0_DATA_0    = 9'h028,
    ADDR_PRE0_P0_CTRL      = 9'h02c,
    ADDR_PRE0_P1_DATA_0    = 9'h030,
    ADDR_PRE0_P1_CTRL      = 9'h034,
    ADDR_PRE0_P2_DATA_0    = 9'h038,
    ADDR_PRE0_P2_CTRL      = 9'h03c,
    ADDR_PRE0_P3_DATA_0    = 9'h040,
    ADDR_PRE0_P3_CTRL      = 9'h044,
    ADDR_PRE1_OP_DATA_0    = 9'h048,
    ADDR_PRE1_OP_CTRL      = 9'h04c,
    ADDR_PRE1_P0_DATA_0    = 9'h050,
    ADDR_PRE1_P0_CTRL      = 9'h054,
    ADDR_PRE1_P1_DATA_0    = 9'h058,
    ADDR_PRE1_P1_CTRL      = 9'h05c,
    ADDR_PRE1_P2_DATA_0    = 9'h060,
    ADDR_PRE1_P2_CTRL      = 9'h064,
    ADDR_PRE1_P3_DATA_0    = 9'h068,
    ADDR_PRE1_P3_CTRL      = 9'h06c,
    ADDR_PRE2_OP_DATA_0    = 9'h070,
    ADDR_PRE2_OP_CTRL      = 9'h074,
    ADDR_PRE2_P0_DATA_0    = 9'h078,
    ADDR_PRE2_P0_CTRL      = 9'h07c,
    ADDR_PRE2_P1_DATA_0    = 9'h080,
    ADDR_PRE2_P1_CTRL      = 9'h084,
    ADDR_PRE2_P2_DATA_0    = 9'h088,
    ADDR_PRE2_P2_CTRL      = 9'h08c,
    ADDR_PRE2_P3_DATA_0    = 9'h090,
    ADDR_PRE2_P3_CTRL      = 9'h094,
    ADDR_EDGE_OP_DATA_0    = 9'h098,
    ADDR_EDGE_OP_CTRL      = 9'h09c,
    ADDR_EDGE_P0_DATA_0    = 9'h0a0,
    ADDR_EDGE_P0_CTRL      = 9'h0a4,
    ADDR_EDGE_P1_DATA_0    = 9'h0a8,
    ADDR_EDGE_P1_CTRL      = 9'h0ac,
    ADDR_EDGE_P2_DATA_0    = 9'h0b0,
    ADDR_EDGE_P2_CTRL      = 9'h0b4,
    ADDR_EDGE_P3_DATA_0    = 9'h0b8,
    ADDR_EDGE_P3_CTRL      = 9'h0bc,
    ADDR_POST0_OP_DATA_0   = 9'h0c0,
    ADDR_POST0_OP_CTRL     = 9'h0c4,
    ADDR_POST0_P0_DATA_0   = 9'h0c8,
    ADDR_POST0_P0_CTRL     = 9'h0cc,
    ADDR_POST0_P1_DATA_0   = 9'h0d0,
    ADDR_POST0_P1_CTRL     = 9'h0d4,
    ADDR_POST0_P2_DATA_0   = 9'h0d8,
    ADDR_POST0_P2_CTRL     = 9'h0dc,
    ADDR_POST0_P3_DATA_0   = 9'h0e0,
    ADDR_POST0_P3_CTRL     = 9'h0e4,
    ADDR_POST1_OP_DATA_0   = 9'h0e8,
    ADDR_POST1_OP_CTRL     = 9'h0ec,
    ADDR_POST1_P0_DATA_0   = 9'h0f0,
    ADDR_POST1_P0_CTRL     = 9'h0f4,
    ADDR_POST1_P1_DATA_0   = 9'h0f8,
    ADDR_POST1_P1_CTRL     = 9'h0fc,
    ADDR_POST1_P2_DATA_0   = 9'h100,
    ADDR_POST1_P2_CTRL     = 9'h104,
    ADDR_POST1_P3_DATA_0   = 9'h108,
    ADDR_POST1_P3_CTRL     = 9'h10c,
    ADDR_STATUS_DATA_0     = 9'h110,
    ADDR_STATUS_CTRL       = 9'h114,
    ADDR_CAPABILITY_DATA_0 = 9'h120,
    ADDR_CAPABILITY_CTRL   = 9'h124,
    WRIDLE                 = 2'd0,
    WRDATA                 = 2'd1,
    WRRESP                 = 2'd2,
    WRRESET                = 2'd3,
    RDIDLE                 = 2'd0,
    RDDATA                 = 2'd1,
    RDRESET                = 2'd2,
    ADDR_BITS                = 9;

//------------------------Local signal-------------------
    reg  [1:0]                    wstate = WRRESET;
    reg  [1:0]                    wnext;
    reg  [ADDR_BITS-1:0]          waddr;
    wire [C_S_AXI_DATA_WIDTH-1:0] wmask;
    wire                          aw_hs;
    wire                          w_hs;
    reg  [1:0]                    rstate = RDRESET;
    reg  [1:0]                    rnext;
    reg  [C_S_AXI_DATA_WIDTH-1:0] rdata;
    wire                          ar_hs;
    wire [ADDR_BITS-1:0]          raddr;
    // internal registers
    reg                           int_ap_idle = 1'b0;
    reg                           int_ap_ready = 1'b0;
    wire                          task_ap_ready;
    reg                           int_ap_done = 1'b0;
    wire                          task_ap_done;
    reg                           int_task_ap_done = 1'b0;
    reg                           int_ap_start = 1'b0;
    reg                           int_interrupt = 1'b0;
    reg                           int_auto_restart = 1'b0;
    reg                           auto_restart_status = 1'b0;
    wire                          auto_restart_done;
    reg                           int_gie = 1'b0;
    reg  [1:0]                    int_ier = 2'b0;
    reg  [1:0]                    int_isr = 2'b0;
    reg  [31:0]                   int_rows = 'b0;
    reg  [31:0]                   int_cols = 'b0;
    reg  [7:0]                    int_pre0_op = 'b0;
    reg  [31:0]                   int_pre0_p0 = 'b0;
    reg  [31:0]                   int_pre0_p1 = 'b0;
    reg  [31:0]                   int_pre0_p2 = 'b0;
    reg  [31:0]                   int_pre0_p3 = 'b0;
    reg  [7:0]                    int_pre1_op = 'b0;
    reg  [31:0]                   int_pre1_p0 = 'b0;
    reg  [31:0]                   int_pre1_p1 = 'b0;
    reg  [31:0]                   int_pre1_p2 = 'b0;
    reg  [31:0]                   int_pre1_p3 = 'b0;
    reg  [7:0]                    int_pre2_op = 'b0;
    reg  [31:0]                   int_pre2_p0 = 'b0;
    reg  [31:0]                   int_pre2_p1 = 'b0;
    reg  [31:0]                   int_pre2_p2 = 'b0;
    reg  [31:0]                   int_pre2_p3 = 'b0;
    reg  [7:0]                    int_edge_op = 'b0;
    reg  [31:0]                   int_edge_p0 = 'b0;
    reg  [31:0]                   int_edge_p1 = 'b0;
    reg  [31:0]                   int_edge_p2 = 'b0;
    reg  [31:0]                   int_edge_p3 = 'b0;
    reg  [7:0]                    int_post0_op = 'b0;
    reg  [31:0]                   int_post0_p0 = 'b0;
    reg  [31:0]                   int_post0_p1 = 'b0;
    reg  [31:0]                   int_post0_p2 = 'b0;
    reg  [31:0]                   int_post0_p3 = 'b0;
    reg  [7:0]                    int_post1_op = 'b0;
    reg  [31:0]                   int_post1_p0 = 'b0;
    reg  [31:0]                   int_post1_p1 = 'b0;
    reg  [31:0]                   int_post1_p2 = 'b0;
    reg  [31:0]                   int_post1_p3 = 'b0;
    reg                           int_status_ap_vld;
    reg  [31:0]                   int_status = 'b0;
    reg                           int_capability_ap_vld;
    reg  [31:0]                   int_capability = 'b0;

//------------------------Instantiation------------------


//------------------------AXI write fsm------------------
assign AWREADY = (wstate == WRIDLE);
assign WREADY  = (wstate == WRDATA);
assign BVALID  = (wstate == WRRESP);
assign BRESP   = 2'b00;  // OKAY
assign wmask   = { {8{WSTRB[3]}}, {8{WSTRB[2]}}, {8{WSTRB[1]}}, {8{WSTRB[0]}} };
assign aw_hs   = AWVALID & AWREADY;
assign w_hs    = WVALID & WREADY;

// wstate
always @(posedge ACLK) begin
    if (ARESET)
        wstate <= WRRESET;
    else if (ACLK_EN)
        wstate <= wnext;
end

// wnext
always @(*) begin
    case (wstate)
        WRIDLE:
            if (AWVALID)
                wnext = WRDATA;
            else
                wnext = WRIDLE;
        WRDATA:
            if (WVALID)
                wnext = WRRESP;
            else
                wnext = WRDATA;
        WRRESP:
            if (BREADY & BVALID)
                wnext = WRIDLE;
            else
                wnext = WRRESP;
        default:
            wnext = WRIDLE;
    endcase
end

// waddr
always @(posedge ACLK) begin
    if (ACLK_EN) begin
        if (aw_hs)
            waddr <= {AWADDR[ADDR_BITS-1:2], {2{1'b0}}};
    end
end

//------------------------AXI read fsm-------------------
assign ARREADY = (rstate == RDIDLE);
assign RDATA   = rdata;
assign RRESP   = 2'b00;  // OKAY
assign RVALID  = (rstate == RDDATA);
assign ar_hs   = ARVALID & ARREADY;
assign raddr   = ARADDR[ADDR_BITS-1:0];

// rstate
always @(posedge ACLK) begin
    if (ARESET)
        rstate <= RDRESET;
    else if (ACLK_EN)
        rstate <= rnext;
end

// rnext
always @(*) begin
    case (rstate)
        RDIDLE:
            if (ARVALID)
                rnext = RDDATA;
            else
                rnext = RDIDLE;
        RDDATA:
            if (RREADY & RVALID)
                rnext = RDIDLE;
            else
                rnext = RDDATA;
        default:
            rnext = RDIDLE;
    endcase
end

// rdata
always @(posedge ACLK) begin
    if (ACLK_EN) begin
        if (ar_hs) begin
            rdata <= 'b0;
            case (raddr)
                ADDR_AP_CTRL: begin
                    rdata[0] <= int_ap_start;
                    rdata[1] <= int_task_ap_done;
                    rdata[2] <= int_ap_idle;
                    rdata[3] <= int_ap_ready;
                    rdata[7] <= int_auto_restart;
                    rdata[9] <= int_interrupt;
                end
                ADDR_GIE: begin
                    rdata <= int_gie;
                end
                ADDR_IER: begin
                    rdata <= int_ier;
                end
                ADDR_ISR: begin
                    rdata <= int_isr;
                end
                ADDR_ROWS_DATA_0: begin
                    rdata <= int_rows[31:0];
                end
                ADDR_COLS_DATA_0: begin
                    rdata <= int_cols[31:0];
                end
                ADDR_PRE0_OP_DATA_0: begin
                    rdata <= int_pre0_op[7:0];
                end
                ADDR_PRE0_P0_DATA_0: begin
                    rdata <= int_pre0_p0[31:0];
                end
                ADDR_PRE0_P1_DATA_0: begin
                    rdata <= int_pre0_p1[31:0];
                end
                ADDR_PRE0_P2_DATA_0: begin
                    rdata <= int_pre0_p2[31:0];
                end
                ADDR_PRE0_P3_DATA_0: begin
                    rdata <= int_pre0_p3[31:0];
                end
                ADDR_PRE1_OP_DATA_0: begin
                    rdata <= int_pre1_op[7:0];
                end
                ADDR_PRE1_P0_DATA_0: begin
                    rdata <= int_pre1_p0[31:0];
                end
                ADDR_PRE1_P1_DATA_0: begin
                    rdata <= int_pre1_p1[31:0];
                end
                ADDR_PRE1_P2_DATA_0: begin
                    rdata <= int_pre1_p2[31:0];
                end
                ADDR_PRE1_P3_DATA_0: begin
                    rdata <= int_pre1_p3[31:0];
                end
                ADDR_PRE2_OP_DATA_0: begin
                    rdata <= int_pre2_op[7:0];
                end
                ADDR_PRE2_P0_DATA_0: begin
                    rdata <= int_pre2_p0[31:0];
                end
                ADDR_PRE2_P1_DATA_0: begin
                    rdata <= int_pre2_p1[31:0];
                end
                ADDR_PRE2_P2_DATA_0: begin
                    rdata <= int_pre2_p2[31:0];
                end
                ADDR_PRE2_P3_DATA_0: begin
                    rdata <= int_pre2_p3[31:0];
                end
                ADDR_EDGE_OP_DATA_0: begin
                    rdata <= int_edge_op[7:0];
                end
                ADDR_EDGE_P0_DATA_0: begin
                    rdata <= int_edge_p0[31:0];
                end
                ADDR_EDGE_P1_DATA_0: begin
                    rdata <= int_edge_p1[31:0];
                end
                ADDR_EDGE_P2_DATA_0: begin
                    rdata <= int_edge_p2[31:0];
                end
                ADDR_EDGE_P3_DATA_0: begin
                    rdata <= int_edge_p3[31:0];
                end
                ADDR_POST0_OP_DATA_0: begin
                    rdata <= int_post0_op[7:0];
                end
                ADDR_POST0_P0_DATA_0: begin
                    rdata <= int_post0_p0[31:0];
                end
                ADDR_POST0_P1_DATA_0: begin
                    rdata <= int_post0_p1[31:0];
                end
                ADDR_POST0_P2_DATA_0: begin
                    rdata <= int_post0_p2[31:0];
                end
                ADDR_POST0_P3_DATA_0: begin
                    rdata <= int_post0_p3[31:0];
                end
                ADDR_POST1_OP_DATA_0: begin
                    rdata <= int_post1_op[7:0];
                end
                ADDR_POST1_P0_DATA_0: begin
                    rdata <= int_post1_p0[31:0];
                end
                ADDR_POST1_P1_DATA_0: begin
                    rdata <= int_post1_p1[31:0];
                end
                ADDR_POST1_P2_DATA_0: begin
                    rdata <= int_post1_p2[31:0];
                end
                ADDR_POST1_P3_DATA_0: begin
                    rdata <= int_post1_p3[31:0];
                end
                ADDR_STATUS_DATA_0: begin
                    rdata <= int_status[31:0];
                end
                ADDR_STATUS_CTRL: begin
                    rdata[0] <= int_status_ap_vld;
                end
                ADDR_CAPABILITY_DATA_0: begin
                    rdata <= int_capability[31:0];
                end
                ADDR_CAPABILITY_CTRL: begin
                    rdata[0] <= int_capability_ap_vld;
                end
            endcase
        end
    end
end


//------------------------Register logic-----------------
assign interrupt         = int_interrupt;
assign ap_start          = int_ap_start;
assign task_ap_done      = (ap_done && !auto_restart_status) || auto_restart_done;
assign task_ap_ready     = ap_ready && !int_auto_restart;
assign auto_restart_done = auto_restart_status && (ap_idle && !int_ap_idle);
assign rows              = int_rows;
assign cols              = int_cols;
assign pre0_op           = int_pre0_op;
assign pre0_p0           = int_pre0_p0;
assign pre0_p1           = int_pre0_p1;
assign pre0_p2           = int_pre0_p2;
assign pre0_p3           = int_pre0_p3;
assign pre1_op           = int_pre1_op;
assign pre1_p0           = int_pre1_p0;
assign pre1_p1           = int_pre1_p1;
assign pre1_p2           = int_pre1_p2;
assign pre1_p3           = int_pre1_p3;
assign pre2_op           = int_pre2_op;
assign pre2_p0           = int_pre2_p0;
assign pre2_p1           = int_pre2_p1;
assign pre2_p2           = int_pre2_p2;
assign pre2_p3           = int_pre2_p3;
assign edge_op           = int_edge_op;
assign edge_p0           = int_edge_p0;
assign edge_p1           = int_edge_p1;
assign edge_p2           = int_edge_p2;
assign edge_p3           = int_edge_p3;
assign post0_op          = int_post0_op;
assign post0_p0          = int_post0_p0;
assign post0_p1          = int_post0_p1;
assign post0_p2          = int_post0_p2;
assign post0_p3          = int_post0_p3;
assign post1_op          = int_post1_op;
assign post1_p0          = int_post1_p0;
assign post1_p1          = int_post1_p1;
assign post1_p2          = int_post1_p2;
assign post1_p3          = int_post1_p3;
// int_interrupt
always @(posedge ACLK) begin
    if (ARESET)
        int_interrupt <= 1'b0;
    else if (ACLK_EN) begin
        if (int_gie && (|int_isr))
            int_interrupt <= 1'b1;
        else
            int_interrupt <= 1'b0;
    end
end

// int_ap_start
always @(posedge ACLK) begin
    if (ARESET)
        int_ap_start <= 1'b0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_AP_CTRL && WSTRB[0] && WDATA[0])
            int_ap_start <= 1'b1;
        else if (ap_ready)
            int_ap_start <= int_auto_restart; // clear on handshake/auto restart
    end
end

// int_ap_done
always @(posedge ACLK) begin
    if (ARESET)
        int_ap_done <= 1'b0;
    else if (ACLK_EN) begin
            int_ap_done <= ap_done;
    end
end

// int_task_ap_done
always @(posedge ACLK) begin
    if (ARESET)
        int_task_ap_done <= 1'b0;
    else if (ACLK_EN) begin
        if (task_ap_done)
            int_task_ap_done <= 1'b1;
        else if (ar_hs && raddr == ADDR_AP_CTRL)
            int_task_ap_done <= 1'b0; // clear on read
    end
end

// int_ap_idle
always @(posedge ACLK) begin
    if (ARESET)
        int_ap_idle <= 1'b0;
    else if (ACLK_EN) begin
            int_ap_idle <= ap_idle;
    end
end

// int_ap_ready
always @(posedge ACLK) begin
    if (ARESET)
        int_ap_ready <= 1'b0;
    else if (ACLK_EN) begin
        if (task_ap_ready)
            int_ap_ready <= 1'b1;
        else if (ar_hs && raddr == ADDR_AP_CTRL)
            int_ap_ready <= 1'b0;
    end
end

// int_auto_restart
always @(posedge ACLK) begin
    if (ARESET)
        int_auto_restart <= 1'b0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_AP_CTRL && WSTRB[0])
            int_auto_restart <= WDATA[7];
    end
end

// auto_restart_status
always @(posedge ACLK) begin
    if (ARESET)
        auto_restart_status <= 1'b0;
    else if (ACLK_EN) begin
        if (int_auto_restart)
            auto_restart_status <= 1'b1;
        else if (ap_idle)
            auto_restart_status <= 1'b0;
    end
end

// int_gie
always @(posedge ACLK) begin
    if (ARESET)
        int_gie <= 1'b0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_GIE && WSTRB[0])
            int_gie <= WDATA[0];
    end
end

// int_ier
always @(posedge ACLK) begin
    if (ARESET)
        int_ier <= 1'b0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_IER && WSTRB[0])
            int_ier <= WDATA[1:0];
    end
end

// int_isr[0]
always @(posedge ACLK) begin
    if (ARESET)
        int_isr[0] <= 1'b0;
    else if (ACLK_EN) begin
        if (int_ier[0] & ap_done)
            int_isr[0] <= 1'b1;
        else if (w_hs && waddr == ADDR_ISR && WSTRB[0])
            int_isr[0] <= int_isr[0] ^ WDATA[0]; // toggle on write
    end
end

// int_isr[1]
always @(posedge ACLK) begin
    if (ARESET)
        int_isr[1] <= 1'b0;
    else if (ACLK_EN) begin
        if (int_ier[1] & ap_ready)
            int_isr[1] <= 1'b1;
        else if (w_hs && waddr == ADDR_ISR && WSTRB[0])
            int_isr[1] <= int_isr[1] ^ WDATA[1]; // toggle on write
    end
end

// int_rows[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_rows[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_ROWS_DATA_0)
            int_rows[31:0] <= (WDATA[31:0] & wmask) | (int_rows[31:0] & ~wmask);
    end
end

// int_cols[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_cols[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_COLS_DATA_0)
            int_cols[31:0] <= (WDATA[31:0] & wmask) | (int_cols[31:0] & ~wmask);
    end
end

// int_pre0_op[7:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_pre0_op[7:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_PRE0_OP_DATA_0)
            int_pre0_op[7:0] <= (WDATA[31:0] & wmask) | (int_pre0_op[7:0] & ~wmask);
    end
end

// int_pre0_p0[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_pre0_p0[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_PRE0_P0_DATA_0)
            int_pre0_p0[31:0] <= (WDATA[31:0] & wmask) | (int_pre0_p0[31:0] & ~wmask);
    end
end

// int_pre0_p1[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_pre0_p1[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_PRE0_P1_DATA_0)
            int_pre0_p1[31:0] <= (WDATA[31:0] & wmask) | (int_pre0_p1[31:0] & ~wmask);
    end
end

// int_pre0_p2[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_pre0_p2[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_PRE0_P2_DATA_0)
            int_pre0_p2[31:0] <= (WDATA[31:0] & wmask) | (int_pre0_p2[31:0] & ~wmask);
    end
end

// int_pre0_p3[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_pre0_p3[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_PRE0_P3_DATA_0)
            int_pre0_p3[31:0] <= (WDATA[31:0] & wmask) | (int_pre0_p3[31:0] & ~wmask);
    end
end

// int_pre1_op[7:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_pre1_op[7:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_PRE1_OP_DATA_0)
            int_pre1_op[7:0] <= (WDATA[31:0] & wmask) | (int_pre1_op[7:0] & ~wmask);
    end
end

// int_pre1_p0[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_pre1_p0[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_PRE1_P0_DATA_0)
            int_pre1_p0[31:0] <= (WDATA[31:0] & wmask) | (int_pre1_p0[31:0] & ~wmask);
    end
end

// int_pre1_p1[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_pre1_p1[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_PRE1_P1_DATA_0)
            int_pre1_p1[31:0] <= (WDATA[31:0] & wmask) | (int_pre1_p1[31:0] & ~wmask);
    end
end

// int_pre1_p2[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_pre1_p2[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_PRE1_P2_DATA_0)
            int_pre1_p2[31:0] <= (WDATA[31:0] & wmask) | (int_pre1_p2[31:0] & ~wmask);
    end
end

// int_pre1_p3[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_pre1_p3[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_PRE1_P3_DATA_0)
            int_pre1_p3[31:0] <= (WDATA[31:0] & wmask) | (int_pre1_p3[31:0] & ~wmask);
    end
end

// int_pre2_op[7:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_pre2_op[7:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_PRE2_OP_DATA_0)
            int_pre2_op[7:0] <= (WDATA[31:0] & wmask) | (int_pre2_op[7:0] & ~wmask);
    end
end

// int_pre2_p0[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_pre2_p0[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_PRE2_P0_DATA_0)
            int_pre2_p0[31:0] <= (WDATA[31:0] & wmask) | (int_pre2_p0[31:0] & ~wmask);
    end
end

// int_pre2_p1[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_pre2_p1[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_PRE2_P1_DATA_0)
            int_pre2_p1[31:0] <= (WDATA[31:0] & wmask) | (int_pre2_p1[31:0] & ~wmask);
    end
end

// int_pre2_p2[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_pre2_p2[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_PRE2_P2_DATA_0)
            int_pre2_p2[31:0] <= (WDATA[31:0] & wmask) | (int_pre2_p2[31:0] & ~wmask);
    end
end

// int_pre2_p3[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_pre2_p3[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_PRE2_P3_DATA_0)
            int_pre2_p3[31:0] <= (WDATA[31:0] & wmask) | (int_pre2_p3[31:0] & ~wmask);
    end
end

// int_edge_op[7:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_edge_op[7:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_EDGE_OP_DATA_0)
            int_edge_op[7:0] <= (WDATA[31:0] & wmask) | (int_edge_op[7:0] & ~wmask);
    end
end

// int_edge_p0[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_edge_p0[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_EDGE_P0_DATA_0)
            int_edge_p0[31:0] <= (WDATA[31:0] & wmask) | (int_edge_p0[31:0] & ~wmask);
    end
end

// int_edge_p1[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_edge_p1[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_EDGE_P1_DATA_0)
            int_edge_p1[31:0] <= (WDATA[31:0] & wmask) | (int_edge_p1[31:0] & ~wmask);
    end
end

// int_edge_p2[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_edge_p2[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_EDGE_P2_DATA_0)
            int_edge_p2[31:0] <= (WDATA[31:0] & wmask) | (int_edge_p2[31:0] & ~wmask);
    end
end

// int_edge_p3[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_edge_p3[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_EDGE_P3_DATA_0)
            int_edge_p3[31:0] <= (WDATA[31:0] & wmask) | (int_edge_p3[31:0] & ~wmask);
    end
end

// int_post0_op[7:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_post0_op[7:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_POST0_OP_DATA_0)
            int_post0_op[7:0] <= (WDATA[31:0] & wmask) | (int_post0_op[7:0] & ~wmask);
    end
end

// int_post0_p0[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_post0_p0[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_POST0_P0_DATA_0)
            int_post0_p0[31:0] <= (WDATA[31:0] & wmask) | (int_post0_p0[31:0] & ~wmask);
    end
end

// int_post0_p1[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_post0_p1[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_POST0_P1_DATA_0)
            int_post0_p1[31:0] <= (WDATA[31:0] & wmask) | (int_post0_p1[31:0] & ~wmask);
    end
end

// int_post0_p2[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_post0_p2[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_POST0_P2_DATA_0)
            int_post0_p2[31:0] <= (WDATA[31:0] & wmask) | (int_post0_p2[31:0] & ~wmask);
    end
end

// int_post0_p3[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_post0_p3[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_POST0_P3_DATA_0)
            int_post0_p3[31:0] <= (WDATA[31:0] & wmask) | (int_post0_p3[31:0] & ~wmask);
    end
end

// int_post1_op[7:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_post1_op[7:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_POST1_OP_DATA_0)
            int_post1_op[7:0] <= (WDATA[31:0] & wmask) | (int_post1_op[7:0] & ~wmask);
    end
end

// int_post1_p0[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_post1_p0[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_POST1_P0_DATA_0)
            int_post1_p0[31:0] <= (WDATA[31:0] & wmask) | (int_post1_p0[31:0] & ~wmask);
    end
end

// int_post1_p1[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_post1_p1[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_POST1_P1_DATA_0)
            int_post1_p1[31:0] <= (WDATA[31:0] & wmask) | (int_post1_p1[31:0] & ~wmask);
    end
end

// int_post1_p2[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_post1_p2[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_POST1_P2_DATA_0)
            int_post1_p2[31:0] <= (WDATA[31:0] & wmask) | (int_post1_p2[31:0] & ~wmask);
    end
end

// int_post1_p3[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_post1_p3[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_POST1_P3_DATA_0)
            int_post1_p3[31:0] <= (WDATA[31:0] & wmask) | (int_post1_p3[31:0] & ~wmask);
    end
end

// int_status
always @(posedge ACLK) begin
    if (ARESET)
        int_status <= 0;
    else if (ACLK_EN) begin
        if (status_ap_vld)
            int_status <= status;
    end
end

// int_status_ap_vld
always @(posedge ACLK) begin
    if (ARESET)
        int_status_ap_vld <= 1'b0;
    else if (ACLK_EN) begin
        if (status_ap_vld)
            int_status_ap_vld <= 1'b1;
        else if (ar_hs && raddr == ADDR_STATUS_CTRL)
            int_status_ap_vld <= 1'b0; // clear on read
    end
end

// int_capability
always @(posedge ACLK) begin
    if (ARESET)
        int_capability <= 0;
    else if (ACLK_EN) begin
        if (capability_ap_vld)
            int_capability <= capability;
    end
end

// int_capability_ap_vld
always @(posedge ACLK) begin
    if (ARESET)
        int_capability_ap_vld <= 1'b0;
    else if (ACLK_EN) begin
        if (capability_ap_vld)
            int_capability_ap_vld <= 1'b1;
        else if (ar_hs && raddr == ADDR_CAPABILITY_CTRL)
            int_capability_ap_vld <= 1'b0; // clear on read
    end
end

//synthesis translate_off
always @(posedge ACLK) begin
    if (ACLK_EN) begin
        if (int_gie & ~int_isr[0] & int_ier[0] & ap_done)
            $display ("// Interrupt Monitor : interrupt for ap_done detected @ \"%0t\"", $time);
        if (int_gie & ~int_isr[1] & int_ier[1] & ap_ready)
            $display ("// Interrupt Monitor : interrupt for ap_ready detected @ \"%0t\"", $time);
    end
end
//synthesis translate_on

//------------------------Memory logic-------------------

endmodule
