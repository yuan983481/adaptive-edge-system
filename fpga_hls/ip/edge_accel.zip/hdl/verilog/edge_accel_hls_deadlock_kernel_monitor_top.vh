
wire kernel_monitor_reset;
wire kernel_monitor_clock;
wire kernel_monitor_report;
assign kernel_monitor_reset = ~ap_rst_n;
assign kernel_monitor_clock = ap_clk;
assign kernel_monitor_report = 1'b0;
wire [3:0] axis_block_sigs;
wire [9:0] inst_idle_sigs;
wire [2:0] inst_block_sigs;
wire kernel_block;

assign axis_block_sigs[0] = ~Block_entry_proc_U0.grp_axis_to_pixel_fu_544.grp_axis_to_pixel_Pipeline_VITIS_LOOP_56_1_VITIS_LOOP_57_2_fu_66.s_axis_TDATA_blk_n;
assign axis_block_sigs[1] = ~Block_entry_proc_U0.grp_pixel_to_axis_fu_835.grp_pixel_to_axis_Pipeline_VITIS_LOOP_74_1_VITIS_LOOP_75_2_fu_66.m_axis_TDATA_blk_n;
assign axis_block_sigs[2] = ~Block_entry_proc_U0.grp_Block_entry_proc_Pipeline_VITIS_LOOP_1623_1_VITIS_LOOP_1624_2_fu_856.s_axis_TDATA_blk_n;
assign axis_block_sigs[3] = ~Block_entry_proc_U0.grp_Block_entry_proc_Pipeline_VITIS_LOOP_1623_1_VITIS_LOOP_1624_2_fu_856.m_axis_TDATA_blk_n;

assign inst_idle_sigs[0] = Block_entry_proc_2_U0.ap_idle;
assign inst_block_sigs[0] = (Block_entry_proc_2_U0.ap_done & ~Block_entry_proc_2_U0.ap_continue);
assign inst_idle_sigs[1] = validate_config_U0.ap_idle;
assign inst_block_sigs[1] = (validate_config_U0.ap_done & ~validate_config_U0.ap_continue);
assign inst_idle_sigs[2] = Block_entry_proc_U0.ap_idle;
assign inst_block_sigs[2] = (Block_entry_proc_U0.ap_done & ~Block_entry_proc_U0.ap_continue);

assign inst_idle_sigs[3] = 1'b0;
assign inst_idle_sigs[4] = Block_entry_proc_U0.ap_idle;
assign inst_idle_sigs[5] = Block_entry_proc_U0.grp_axis_to_pixel_fu_544.ap_idle;
assign inst_idle_sigs[6] = Block_entry_proc_U0.grp_axis_to_pixel_fu_544.grp_axis_to_pixel_Pipeline_VITIS_LOOP_56_1_VITIS_LOOP_57_2_fu_66.ap_idle;
assign inst_idle_sigs[7] = Block_entry_proc_U0.grp_pixel_to_axis_fu_835.ap_idle;
assign inst_idle_sigs[8] = Block_entry_proc_U0.grp_pixel_to_axis_fu_835.grp_pixel_to_axis_Pipeline_VITIS_LOOP_74_1_VITIS_LOOP_75_2_fu_66.ap_idle;
assign inst_idle_sigs[9] = Block_entry_proc_U0.grp_Block_entry_proc_Pipeline_VITIS_LOOP_1623_1_VITIS_LOOP_1624_2_fu_856.ap_idle;

edge_accel_hls_deadlock_idx0_monitor edge_accel_hls_deadlock_idx0_monitor_U (
    .clock(kernel_monitor_clock),
    .reset(kernel_monitor_reset),
    .axis_block_sigs(axis_block_sigs),
    .inst_idle_sigs(inst_idle_sigs),
    .inst_block_sigs(inst_block_sigs),
    .block(kernel_block)
);


always @ (kernel_block or kernel_monitor_reset) begin
    if (kernel_block == 1'b1 && kernel_monitor_reset == 1'b0) begin
        find_kernel_block = 1'b1;
    end
    else begin
        find_kernel_block = 1'b0;
    end
end
